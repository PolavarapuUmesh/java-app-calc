sudo systemctl start tomcat

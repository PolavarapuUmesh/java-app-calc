chmod +x scripts/*.sh
sudo systemctl start tomcat

sudo systemctl stop tomcat
sudo systemctl status tomcat
